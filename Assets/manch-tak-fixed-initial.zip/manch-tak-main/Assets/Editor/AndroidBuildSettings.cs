using UnityEditor;
using UnityEngine;

namespace ManchTak.Editor
{
    [InitializeOnLoad]
    internal static class AndroidBuildSettings
    {
        static AndroidBuildSettings()
        {
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.faridtak.manchtak");
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.Android.bundleVersionCode = 1;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.companyName = "ManchTak";
            PlayerSettings.productName = "منچ تک";
        }
    }
}
