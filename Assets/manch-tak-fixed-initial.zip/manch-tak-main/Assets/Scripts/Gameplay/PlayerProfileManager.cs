
using System;

namespace ManchTak
{
    public class PlayerProfileManager
    {
        public PlayerProfileController ProfileController
        {
            get;
            private set;
        }

        public PlayerProfileViewController ProfileViewController
        {
            get;
            private set;
        }

        public PlayerProfileData Profile
        {
            get
            {
                return ProfileController.Profile;
            }
        }

        public event Action<int> OnLevelUp;

        public PlayerProfileManager(
            string playerId,
            string defaultDisplayName = "بازیکن جدید")
        {
            if (string.IsNullOrWhiteSpace(playerId))
            {
                throw new ArgumentException(
                    "شناسه بازیکن معتبر نیست.",
                    nameof(playerId)
                );
            }

            PlayerProfileData savedProfile =
                PlayerProfileStorage.Load(playerId);

            if (savedProfile == null)
            {
                savedProfile = new PlayerProfileData(
                    playerId,
                    defaultDisplayName,
                    1
                );
            }

            if (savedProfile.ProcessedMatchIds == null)
            {
                savedProfile.ProcessedMatchIds =
                    new string[0];
            }

            ProfileController =
                new PlayerProfileController(savedProfile);

            ProfileViewController =
                new PlayerProfileViewController();

            ProfileController.OnProfileChanged +=
                HandleProfileChanged;

            ProfileController.OnLevelUp += HandleLevelUp;

            SyncViewProfile();

            SaveProfile(Profile);
        }

        private void HandleProfileChanged(
            PlayerProfileData profile)
        {
            if (profile == null)
                return;

            SaveProfile(profile);
            SyncViewProfile();
        }

        private void SyncViewProfile()
        {
            if (ProfileViewController == null ||
                ProfileController == null)
            {
                return;
            }

            ProfileViewController.SyncProgress(Profile);
        }

        private void SaveProfile(PlayerProfileData profile)
        {
            if (profile == null)
                return;

            PlayerProfileStorage.Save(profile);
        }

        private void HandleLevelUp(int newLevel)
        {
            SyncViewProfile();
            OnLevelUp?.Invoke(newLevel);
        }

        private bool HasProcessedMatch(string matchId)
        {
            if (string.IsNullOrWhiteSpace(matchId) ||
                Profile.ProcessedMatchIds == null)
            {
                return false;
            }

            foreach (string savedMatchId in Profile.ProcessedMatchIds)
            {
                if (string.Equals(
                    savedMatchId,
                    matchId,
                    StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }

        private void MarkMatchAsProcessed(string matchId)
        {
            string[] oldIds = Profile.ProcessedMatchIds
                ?? new string[0];

            string[] newIds = new string[oldIds.Length + 1];

            Array.Copy(
                oldIds,
                newIds,
                oldIds.Length
            );

            newIds[newIds.Length - 1] = matchId;

            Profile.ProcessedMatchIds = newIds;
        }

        public bool ApplyMatchResult(MatchResult result)
        {
            if (result == null ||
                result.Status != MatchResultStatus.Completed ||
                string.IsNullOrWhiteSpace(result.MatchId))
            {
                return false;
            }

            if (HasProcessedMatch(result.MatchId))
                return false;

            string playerId = Profile.PlayerId;

            if (string.IsNullOrWhiteSpace(playerId))
                return false;

            bool isWinner = string.Equals(
                result.WinnerId,
                playerId,
                StringComparison.Ordinal
            );

            bool isLoser = false;

            if (result.LoserIds != null)
            {
                foreach (string loserId in result.LoserIds)
                {
                    if (string.Equals(
                        loserId,
                        playerId,
                        StringComparison.Ordinal))
                    {
                        isLoser = true;
                        break;
                    }
                }
            }

            if (!isWinner && !isLoser)
                return false;

            int rewardXP = isWinner
                ? PlayerProgressionRules.WinnerXP
                : PlayerProgressionRules.LoserXP;

            MarkMatchAsProcessed(result.MatchId);

            ProfileController.AddXP(rewardXP);

            if (isWinner)
                ProfileController.RecordWin();
            else
                ProfileController.RecordLoss();

            SaveProfile(Profile);
            SyncViewProfile();

            return true;
        }

        public bool ChangeDisplayName(string newName)
        {
            return ProfileController.UpdateDisplayName(newName);
        }

        public bool ChangeAvatar(int avatarId)
        {
            if (!PlayerAvatarCatalog.IsUnlocked(
                avatarId,
                Profile.PlayerLevel))
            {
                return false;
            }

            return ProfileController.UpdateAvatar(avatarId);
        }

        public void UpdateLevel(int level)
        {
            ProfileController.UpdateLevel(level);
        }

        public bool AddXP(int amount)
        {
            return ProfileController.AddXP(amount);
        }

        public bool AddWinXP()
        {
            return ProfileController.AddWinXP();
        }

        public bool AddLoseXP()
        {
            return ProfileController.AddLoseXP();
        }

        public void RecordWin()
        {
            ProfileController.RecordWin();
        }

        public void RecordLoss()
        {
            ProfileController.RecordLoss();
        }

        public int GetRemainingXP()
        {
            return ProfileController.GetRemainingXP();
        }

        public float GetLevelProgress()
        {
            return ProfileController.GetLevelProgress();
        }

        // اتصال نشان لول به پروفایل بازیکن
        public void BindLevelBadge(PlayerLevelBadgeBinder binder)
        {
            if (binder == null)
                return;

            binder.Bind(ProfileViewController);
        }

        public void Save()
        {
            SaveProfile(Profile);
        }

        public void Close()
        {
            SaveProfile(Profile);

            ProfileController.OnProfileChanged -=
                HandleProfileChanged;

            ProfileController.OnLevelUp -= HandleLevelUp;
        }
    }
}
