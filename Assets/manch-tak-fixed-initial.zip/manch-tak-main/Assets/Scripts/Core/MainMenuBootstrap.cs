using UnityEngine;
using UnityEngine.UI;

namespace ManchTak
{
    public sealed class MainMenuBootstrap : MonoBehaviour
    {
        private void Start()
        {
            Screen.orientation = ScreenOrientation.Portrait;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;

            var canvasObject = new GameObject("MainCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.matchWidthOrHeight = 0.5f;

            var eventSystem = new GameObject("EventSystem",
                typeof(UnityEngine.EventSystems.EventSystem),
                typeof(UnityEngine.EventSystems.StandaloneInputModule));

            CreateText(canvas.transform, "منچ تک", 78, new Vector2(0, 620), new Vector2(900, 150));
            CreateText(canvas.transform, "نسخه آزمایشی - منوی اولیه", 34, new Vector2(0, 500), new Vector2(900, 90));

            CreateButton(canvas.transform, "بازی آفلاین دونفره", new Vector2(0, 250), () =>
                ShowMessage(canvas.transform, "حالت دونفره انتخاب شد"));
            CreateButton(canvas.transform, "بازی آفلاین چهارنفره", new Vector2(0, 80), () =>
                ShowMessage(canvas.transform, "حالت چهارنفره انتخاب شد"));
            CreateButton(canvas.transform, "بازی آنلاین", new Vector2(0, -90), () =>
                ShowMessage(canvas.transform, "بخش آنلاین هنوز در حال آماده‌سازی است"));
            CreateText(canvas.transform, "برای ادامه توسعه، ابتدا ساخت APK و تست روی گوشی انجام می‌شود.",
                26, new Vector2(0, -420), new Vector2(900, 140));
        }

        private static Text CreateText(Transform parent, string value, int size, Vector2 position, Vector2 dimensions)
        {
            var go = new GameObject("Text_" + value, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = dimensions;
            var text = go.GetComponent<Text>();
            text.text = value;
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = size;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = Color.white;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            return text;
        }

        private static void CreateButton(Transform parent, string caption, Vector2 position, UnityEngine.Events.UnityAction action)
        {
            var go = new GameObject("Button_" + caption, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = new Vector2(760, 125);
            var image = go.GetComponent<Image>();
            image.color = new Color(0.12f, 0.38f, 0.28f, 1f);
            var button = go.GetComponent<Button>();
            button.onClick.AddListener(action);
            CreateText(go.transform, caption, 42, Vector2.zero, new Vector2(720, 110));
        }

        private static void ShowMessage(Transform parent, string message)
        {
            var existing = parent.Find("SelectionMessage");
            if (existing != null) Destroy(existing.gameObject);
            var text = CreateText(parent, message, 32, new Vector2(0, -270), new Vector2(900, 100));
            text.gameObject.name = "SelectionMessage";
        }
    }
}
